-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 03 Oca 2023, 13:24:27
-- Sunucu sürümü: 8.0.28
-- PHP Sürümü: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `badminton`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `antrenörler`
--

CREATE TABLE `antrenörler` (
  `antrenör_id` int NOT NULL,
  `adi` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `soyadi` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telno` int NOT NULL,
  `adres` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `antrenörler`
--

INSERT INTO `antrenörler` (`antrenör_id`, `adi`, `soyadi`, `telno`, `adres`) VALUES
(1, 'sertan', 'bilgin', 3255555, 'sdfgsdfgsdfgsdfg'),
(2, 'mert', 'ak', 4684654, 'fgsdfgsdfgsdfsdf');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `giris`
--

CREATE TABLE `giris` (
  `giris_id` int NOT NULL,
  `Adi` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Soyadi` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dogumTarihi` date NOT NULL,
  `kullaniciAdi` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sifre` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `giris`
--

INSERT INTO `giris` (`giris_id`, `Adi`, `Soyadi`, `dogumTarihi`, `kullaniciAdi`, `sifre`, `admin`) VALUES
(1, 'sertan', 'bilgin', '2013-03-20', 'asd', 'asd', 1),
(2, 'elif', 'kocaoğlu', '2002-02-02', 'elocan', '9874', 0),
(4, 'sertan', 'bilgin', '2012-12-20', 'a', '1', 0),
(8, 'sıla', 'a', '2003-01-20', 'a', '1', 0);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `oyuncular`
--

CREATE TABLE `oyuncular` (
  `id` int NOT NULL,
  `Adi` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Soyadi` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `TelNo` double NOT NULL,
  `Adres` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `BaslangıcTarihi` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `oyuncular`
--

INSERT INTO `oyuncular` (`id`, `Adi`, `Soyadi`, `TelNo`, `Adres`, `BaslangıcTarihi`) VALUES
(2, 'Tyler', 'Durden', 5555555551, '100.yıl mahallesi candan sitesi  d blok', '2020-09-24'),
(4, 'Elif', 'Osmankocaoğlu', 5555555553, '100.yıl mahallesi candan sitesi  d blok', '2020-02-18'),
(5, 'Mert', 'Özdemir', 5555555554, '100.yıl mahallesi candan sitesi  d blok', '2015-11-20'),
(6, 'sertan', 'bilgin', 5555555557, '100.yıl mahallesi aaa sokak a blok daire 8', '2019-03-13');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `raket`
--

CREATE TABLE `raket` (
  `raket_id` int NOT NULL,
  `marka` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stok` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `raket`
--

INSERT INTO `raket` (`raket_id`, `marka`, `stok`) VALUES
(1, 'Yonex', 500),
(2, 'Avessa', 330),
(3, 'Selex', 120),
(4, 'Altis', 75);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `saha`
--

CREATE TABLE `saha` (
  `Saha_id` int NOT NULL,
  `özellik1` varchar(70) COLLATE utf8mb4_unicode_ci NOT NULL,
  `özellik2` varchar(70) COLLATE utf8mb4_unicode_ci NOT NULL,
  `renk` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `saha`
--

INSERT INTO `saha` (`Saha_id`, `özellik1`, `özellik2`, `renk`) VALUES
(1, ' İTHAL PVC SPOR ZEMİN', 'YÜKSEK DAYANIKLILIK', 'YEŞİL-MAVİ'),
(2, '33 lm’lik 2 rulodan oluşan kit ', 'Optimal badminton uygulaması için\r\n', ' Nane yeşili');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `toplar`
--

CREATE TABLE `toplar` (
  `top_id` int NOT NULL,
  `marka` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stok` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Tablo döküm verisi `toplar`
--

INSERT INTO `toplar` (`top_id`, `marka`, `stok`) VALUES
(1, 'Yonex', 1652),
(2, 'selex', 164);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `antrenörler`
--
ALTER TABLE `antrenörler`
  ADD PRIMARY KEY (`antrenör_id`);

--
-- Tablo için indeksler `giris`
--
ALTER TABLE `giris`
  ADD PRIMARY KEY (`giris_id`);

--
-- Tablo için indeksler `oyuncular`
--
ALTER TABLE `oyuncular`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `raket`
--
ALTER TABLE `raket`
  ADD PRIMARY KEY (`raket_id`);

--
-- Tablo için indeksler `saha`
--
ALTER TABLE `saha`
  ADD PRIMARY KEY (`Saha_id`);

--
-- Tablo için indeksler `toplar`
--
ALTER TABLE `toplar`
  ADD PRIMARY KEY (`top_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `antrenörler`
--
ALTER TABLE `antrenörler`
  MODIFY `antrenör_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `giris`
--
ALTER TABLE `giris`
  MODIFY `giris_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Tablo için AUTO_INCREMENT değeri `oyuncular`
--
ALTER TABLE `oyuncular`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Tablo için AUTO_INCREMENT değeri `raket`
--
ALTER TABLE `raket`
  MODIFY `raket_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `saha`
--
ALTER TABLE `saha`
  MODIFY `Saha_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `toplar`
--
ALTER TABLE `toplar`
  MODIFY `top_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
