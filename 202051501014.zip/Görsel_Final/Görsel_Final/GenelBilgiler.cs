﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data;
using Org.BouncyCastle.Asn1.Crmf;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Runtime.Intrinsics.Arm;
using System.Security.AccessControl;
using System.Data.Common;

namespace Görsel_Final
{
    public partial class GenelBilgiler : Form
    {
        public MySqlConnection mysqlbaglan = new MySqlConnection("Server=127.0.0.1;Database=badminton;Uid=root;Pwd='147896325';");
        MySqlDataAdapter baglayici = new MySqlDataAdapter();
        public GenelBilgiler()
        {
            InitializeComponent();
        }
        void gridAyari()
        {
          

        }
       /* private void digeriniYenile()
        {
            mysqlbaglan.Open();
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM oyuncular", mysqlbaglan);
            DataSet ds = new DataSet();
            da.Fill(ds, "oyuncular");
            dataGridView1.DataSource = ds.Tables[0];
            mysqlbaglan.Close();
        }
        private void datagridGuncelle()
        {
            DataSet ds = new DataSet();
            MySqlDataAdapter da = new MySqlDataAdapter();
            MySqlCommandBuilder cmbd = new MySqlCommandBuilder(da);
            da.Update(ds, "oyuncular");
            MessageBox.Show("Kayıt Güncelledi,");
            digeriniYenile();

        }*/

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {
           
           
        }

        private void GenelBilgiler_Load(object sender, EventArgs e)
        {
            
            textBox1.Visible = false;
            button5.Visible = false;
            button6.Visible = false;
            kayitGetir();
        }
        private void kayitGetir()
        {
            mysqlbaglan.Open();
            string kayit = "SELECT * from oyuncular";
            //oyuncular tablosundaki tüm kayıtları çekecek olan sql sorgusu.
            MySqlCommand komut = new MySqlCommand(kayit, mysqlbaglan);
            //Sorgumuzu ve baglantimizi parametre olarak alan bir SqlCommand nesnesi oluşturuyoruz.
            MySqlDataAdapter da = new MySqlDataAdapter(komut);
            //SqlDataAdapter sınıfı verilerin databaseden aktarılması işlemini gerçekleştirir.
            DataTable dt = new DataTable();
            da.Fill(dt);
            //Bir DataTable oluşturarak DataAdapter ile getirilen verileri tablo içerisine dolduruyoruz.
            dataGridView1.DataSource = dt;
            //Formumuzdaki DataGridViewin veri kaynağını oluşturduğumuz tablo olarak gösteriyoruz.
            mysqlbaglan.Close();
        }

        

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            OyuncuEkleSil oyuncueklesil = new OyuncuEkleSil();
            oyuncueklesil.Show();

            


        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Silmek İstediğiniz Kişinin İDsini giriniz");
            button2.Visible = false;
            textBox1.Visible = true;
            button3.Visible = false;
            button5.Visible = true;
            button6.Visible = true;

        }

        private void button4_Click(object sender, EventArgs e)
        {

           
        }

        public void button5_Click(object sender, EventArgs e)
        {

            DialogResult uyar;

            uyar = MessageBox.Show(this, textBox1.Text + " Üye No'lu Kişinin Kaydını Silmek istiyor musunuz?", "SİLME UYARISI", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (uyar == DialogResult.Yes)

            {
                int n = Convert.ToInt16(textBox1.Text);
                mysqlbaglan.Open();
                string sil = "DELETE FROM oyuncular " + "Where id = '" + n + "'";
                MySqlCommand komut = new MySqlCommand(sil,mysqlbaglan);
                komut.ExecuteNonQuery();
                mysqlbaglan.Close();

                MessageBox.Show("Kayıt  silindi");

                try
                {
                    MySqlDataAdapter adaptor = new MySqlDataAdapter("Select * from oyuncular", mysqlbaglan);
                    DataSet ds = new DataSet();
                    ds.Clear();
                    adaptor.Fill(ds, "oyuncular");
                    dataGridView1.DataSource = ds.Tables["oyuncular"];
                    adaptor.Dispose();
                }
                catch
                {
                    return;
                }
            }

                /* mysqlbaglan.Open();

                  string secmeSorgusu = "SELECT * from oyuncular where id=@id";
                 //id parametresine bağlı olarak müşteri bilgilerini çeken sql kodu
                 MySqlCommand secmeKomutu = new MySqlCommand(secmeSorgusu, mysqlbaglan);
                 secmeKomutu.Parameters.AddWithValue("@musterino", textBox1.Text);
                 //musterino parametremize textbox'dan girilen değeri aktarıyoruz.
                 MySqlDataAdapter da = new MySqlDataAdapter(secmeKomutu);
                 MySqlDataReader dr = secmeKomutu.ExecuteReader();
                 //DataReader ile oyuncu verilerini veritabanından belleğe aktardık.
                 if (dr.Read()) //Datareader herhangi bir okuma yapabiliyorsa aşağıdaki kodlar çalışır.
                 {
                     string isim = dr["Adi"].ToString() + " " + dr["Soyadi"].ToString();
                     dr.Close();
                     //Datareader ile okunan oyuncu ad ve soyadını isim değişkenine atadım.
                     //Datareader açık olduğu sürece başka bir sorgu çalıştıramayacağımız için dr nesnesini kapatıyoruz.
                     DialogResult durum = MessageBox.Show(isim+" kaydını silmek istediğinizden emin misiniz?", "Silme Onayı", MessageBoxButtons.YesNo);
                     //Kullanıcıya silme onayı penceresi açıp, verdiği cevabı durum değişkenine aktardık.
                     if (DialogResult.Yes==durum) // Eğer kullanıcı Evet seçeneğini seçmişse, veritabanından kaydı silecek kodlar çalışır.
                     {
                         string silmeSorgusu = "DELETE from oyuncular where id=@id";
                         //musterino parametresine bağlı olarak müşteri kaydını silen sql sorgusu
                         MySqlCommand silKomutu = new MySqlCommand(silmeSorgusu, mysqlbaglan);
                         silKomutu.Parameters.AddWithValue("@id", textBox1.Text);
                         silKomutu.ExecuteNonQuery();
                         MessageBox.Show("Kayıt Silindi...");
                         //Silme işlemini gerçekleştirdikten sonra kullanıcıya mesaj verdik.
                     }
                 }
                 else
                 { 
                     MessageBox.Show("Müşteri Bulunamadı.");
                    mysqlbaglan.Close();
                  }*/

            }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Visible = false;
            button5.Visible = false;
            button2.Visible = true;
            button3.Visible = true;
            button6.Visible = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            mysqlbaglan.Open();
            string kayit = "SELECT * from oyuncular where Adi=@Adi";
            //musteriler tablosundaki tüm alanları isim parametresi
            MySqlCommand komut = new MySqlCommand(kayit, mysqlbaglan);
            komut.Parameters.AddWithValue("@Adi", textBox2.Text);
            //isim parametremize textbox'dan girilen değeri aktarıyoruz.
            MySqlDataAdapter da = new MySqlDataAdapter(komut);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            mysqlbaglan.Close();
            
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                MySqlDataAdapter adaptor = new MySqlDataAdapter("Select * from oyuncular", mysqlbaglan);
                DataSet ds = new DataSet();
                ds.Clear();
                adaptor.Fill(ds, "oyuncular");
                dataGridView1.DataSource = ds.Tables["oyuncular"];
                adaptor.Dispose();
            }
            catch
            {
                return;
            }
        }

        private void GenelBilgiler_FormClosed(object sender, FormClosedEventArgs e)
        {
            AnaEkran anaekran = new AnaEkran();
            anaekran.Show();
        }
    }
}
