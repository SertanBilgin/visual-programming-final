﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;
                
namespace Görsel_Final
{
    public partial class OyuncuEkleSil : Form
    {
        public MySqlConnection mysqlbaglan = new MySqlConnection("Server=127.0.0.1;Database=badminton;Uid=root;Pwd='147896325';");
        MySqlDataAdapter baglayici = new MySqlDataAdapter();
        public OyuncuEkleSil()
        {
            InitializeComponent();
        }

        private void OyuncuEkleSil_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
               
                mysqlbaglan.Open();
                // ekleme komutunu tanımladım ve insert sorgusunu yazdım.
                MySqlCommand ekle = new MySqlCommand("insert into oyuncular (Adi,Soyadi,TelNo,Adres,BaslangıcTarihi) values ('" + textBox1.Text + "','" + textBox2.Text + "','"  + textBox4.Text + "','"+ richTextBox1.Text+ "','"+ textBox6.Text+"')", mysqlbaglan);
                // sorguyu çalıştırıyorum.
                object sonuc = null;    
                sonuc = ekle.ExecuteNonQuery(); // sorgu çalıştı ve dönen değer objec türünden değişkene geçti eğer değişken boş değilse eklendi boşşsa eklenmedi.
                if (sonuc != null)
                    MessageBox.Show("Veriniz Başarıyla Eklendi", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Veriniz Sisteme Eklenirken Bir Hata Olşutu.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                mysqlbaglan.Close();
            }
            catch (Exception HataYakala)
            {
                MessageBox.Show("Hata: " + HataYakala.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            textBox1.Clear();
            textBox2.Clear();
            textBox4.Clear();
            textBox6.Clear();
            richTextBox1.Clear();

            this.Close();       

            /*if(mysqlbaglan.State == ConnectionState.Closed)
            {
                mysqlbaglan.Open();
                MySqlCommand veriekle = new MySqlCommand("İNSTERT İNTO C_Mysql_Update(Adi,Soyadi,Yas,TelNo,Adres,BaslangıcTarihi) VALUES (@Adi,@Soyadi,@Yas,@TelNo,@Adres,@BaslangicTarihi)",mysqlbaglan);
                veriekle.Parameters.AddWithValue("@Adi", textBox1.Text);
                veriekle.Parameters.AddWithValue("@Soyadi", textBox2.Text);
                veriekle.Parameters.AddWithValue("@Yas", textBox3.Text);
                veriekle.Parameters.AddWithValue("@TelNo", textBox4.Text);
                veriekle.Parameters.AddWithValue("@Adres", richTextBox1.Text);
                veriekle.Parameters.AddWithValue("@BaslangıcTarihi", textBox6.Text);
                veriekle.ExecuteNonQuery();
                mysqlbaglan.Close();
            }
            else
            {
                MessageBox.Show("Veri Ekleme Başarısız");
            }*/
        }
    }
}
