﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Görsel_Final
{
    public partial class Başkan : Form
    {
        public Başkan()
        {
            InitializeComponent();
        }

        private void Başkan_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("C:\\baskan.jpg");


        }

        private void Başkan_FormClosed(object sender, FormClosedEventArgs e)
        {
            AnaEkran anaekran = new AnaEkran();
            anaekran.Show();
        }
    }
}
