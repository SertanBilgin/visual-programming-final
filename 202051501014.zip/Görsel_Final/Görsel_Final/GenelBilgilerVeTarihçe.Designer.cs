﻿namespace Görsel_Final
{
    partial class GenelBilgilerVeTarihçe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Cyan;
            this.button1.Location = new System.Drawing.Point(197, 82);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(330, 65);
            this.button1.TabIndex = 0;
            this.button1.Text = "Badminton Nedir";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.Thistle;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Items.AddRange(new object[] {
            "Tüytop ya da badminton, raket ve bir tür tüylü ",
            "topla oynanan tenis benzeri bir oyundur.",
            "Kaz tüyünden yapılma bir top ve raketle oynanan bir oyun",
            " olan Badminton, topun file üzerinden rakip alana atılması",
            " ve geri dönmesini sağlamak amacına dayanan bir spor dalıdır.",
            "Badminton, kolayca öğrenilebilen, erkek ve kadın,",
            " 7 yaşından 77 yaşına kadar bütün yaş grubunda ",
            "insanların yapabildiği ender spor dallarından biridir. ",
            "Tenis oyunları gurubundan olması nedeniyle rakipler ",
            "arasında bir net(file) bulunur. Dolayısıyla herkes kendine",
            " ayrılan sahada oynar, topu (tüytop) oldukça zararsızdır, böylece",
            " yaralanma veya sakatlanma riski en düşük etkinliklerdendir. ",
            "Her yaşta ve her performans düzeyinde oynanır ve zevk verir, ",
            "kişiyi zorlamaz, aşırı yüklenmenin kötü sonuçları oluşmaz.",
            " Özellikle ayak hareketleriyle sahayı tutma ve hamleleriyle",
            " Türkler’in ata sporu kılıç kullanmaya benzemektedir"});
            this.listBox1.Location = new System.Drawing.Point(12, 2);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(770, 244);
            this.listBox1.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Cyan;
            this.button2.Location = new System.Drawing.Point(197, 308);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(330, 65);
            this.button2.TabIndex = 4;
            this.button2.Text = "Badminton Oyun Kuralları";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Cyan;
            this.button3.Location = new System.Drawing.Point(197, 517);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(330, 65);
            this.button3.TabIndex = 5;
            this.button3.Text = "Tarihçe";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.Color.Thistle;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 20;
            this.listBox2.Items.AddRange(new object[] {
            "Oyuncu :Badminton oynayan herhangi bir kişi.",
            "",
            "Karşılaşma :Her biri bir ya da iki oyuncudan oluşan karşı taraflar arasındaki esa" +
                "s karşılaşma.",
            "",
            "Tekler :Karşılıklı birer oyuncunun oynadığı bir karşılaşma.",
            "",
            "Çiftler :Karşılıklı iki oyuncunun oynadığı bir karşılaşma.",
            "",
            "Servis atan taraf :Servis atışı hakkına sahip olan taraf.",
            "",
            "Servisi karşılayan taraf :Servis atan tarafın karşısındaki taraf.",
            "",
            "Ralli :Servis atışı ile başlayan ve top oyun dışında kalana kadar devam eden bir " +
                "ya da birden fazla vuruş dizisi.",
            "",
            "Vuruş :Oyuncu raketinin herhangi bir ileri hareketi"});
            this.listBox2.Location = new System.Drawing.Point(12, 229);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(770, 244);
            this.listBox2.TabIndex = 6;
            // 
            // listBox3
            // 
            this.listBox3.BackColor = System.Drawing.Color.Thistle;
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 20;
            this.listBox3.Items.AddRange(new object[] {
            "Oyuncu :Badminton oynayan herhangi bir kişi.",
            "",
            "Karşılaşma :Her biri bir ya da iki oyuncudan oluşan karşı taraflar arasındaki esa" +
                "s karşılaşma.",
            "",
            "Tekler :Karşılıklı birer oyuncunun oynadığı bir karşılaşma.",
            "",
            "Çiftler :Karşılıklı iki oyuncunun oynadığı bir karşılaşma.",
            "",
            "Servis atan taraf :Servis atışı hakkına sahip olan taraf.",
            "",
            "Servisi karşılayan taraf :Servis atan tarafın karşısındaki taraf.",
            "",
            "Ralli :Servis atışı ile başlayan ve top oyun dışında kalana kadar devam eden bir " +
                "ya da birden fazla vuruş dizisi.",
            "",
            "Vuruş :Oyuncu raketinin herhangi bir ileri hareketi"});
            this.listBox3.Location = new System.Drawing.Point(12, 421);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(770, 244);
            this.listBox3.TabIndex = 7;
            // 
            // GenelBilgilerVeTarihçe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGreen;
            this.ClientSize = new System.Drawing.Size(790, 666);
            this.Controls.Add(this.listBox3);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button1);
            this.Name = "GenelBilgilerVeTarihçe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Genel Bilgiler";
            this.Load += new System.EventHandler(this.GenelBilgilerVeTarihçe_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Button button1;
        private ListBox listBox1;
        private Button button2;
        private Button button3;
        private ListBox listBox2;
        private ListBox listBox3;
    }
}