﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
namespace Görsel_Final
{
    public partial class Antrenörler : Form
    {
        public Antrenörler()
        {
            InitializeComponent();

        }
        public MySqlConnection mysqlbaglan = new MySqlConnection("Server=127.0.0.1;Database=badminton;Uid=root;Pwd='147896325';");

        private void Antrenörler_Load(object sender, EventArgs e)
        {
            textBox1.Visible = false;
            button5.Visible = false;
            button6.Visible = false;
            kayitGetir();
        }
        private void kayitGetir()
        {
            mysqlbaglan.Open();
            string kayit = "SELECT * from antrenörler";
            //oyuncular tablosundaki tüm kayıtları çekecek olan sql sorgusu.
            MySqlCommand komut = new MySqlCommand(kayit, mysqlbaglan);
            //Sorgumuzu ve baglantimizi parametre olarak alan bir SqlCommand nesnesi oluşturuyoruz.
            MySqlDataAdapter da = new MySqlDataAdapter(komut);
            //SqlDataAdapter sınıfı verilerin databaseden aktarılması işlemini gerçekleştirir.
            DataTable dt = new DataTable();
            da.Fill(dt);
            //Bir DataTable oluşturarak DataAdapter ile getirilen verileri tablo içerisine dolduruyoruz.
            dataGridView1.DataSource = dt;
            //Formumuzdaki DataGridViewin veri kaynağını oluşturduğumuz tablo olarak gösteriyoruz.
            mysqlbaglan.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Silmek İstediğiniz Kişinin İDsini giriniz");
            button2.Visible = false;
            textBox1.Visible = true;
            button3.Visible = false;
            button5.Visible = true;
            button6.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult uyar;

            uyar = MessageBox.Show(this, textBox1.Text + " Üye No'lu Kişinin Kaydını Silmek istiyor musunuz?", "SİLME UYARISI", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (uyar == DialogResult.Yes)

            {
                int n = Convert.ToInt16(textBox1.Text);
                mysqlbaglan.Open();
                string sil = "DELETE FROM oyuncular " + "Where id = '" + n + "'";
                MySqlCommand komut = new MySqlCommand(sil, mysqlbaglan);
                komut.ExecuteNonQuery();
                mysqlbaglan.Close();

            }
            try
            {
                MySqlDataAdapter adaptor = new MySqlDataAdapter("Select * from oyuncular", mysqlbaglan);
                DataSet ds = new DataSet();
                ds.Clear();
                adaptor.Fill(ds, "oyuncular");
                dataGridView1.DataSource = ds.Tables["oyuncular"];
                adaptor.Dispose();
            }
            catch
            {
                return;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Visible = false;
            button5.Visible = false;
            button2.Visible = true;
            button3.Visible = true;
            button6.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            mysqlbaglan.Open();
            string kayit = "SELECT * from oyuncular where Adi=@Adi";
            //musteriler tablosundaki tüm alanları isim parametresi
            MySqlCommand komut = new MySqlCommand(kayit, mysqlbaglan);
            komut.Parameters.AddWithValue("@Adi", textBox2.Text);
            //isim parametremize textbox'dan girilen değeri aktarıyoruz.
            MySqlDataAdapter da = new MySqlDataAdapter(komut);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            mysqlbaglan.Close();
        }

        private void Antrenörler_FormClosed(object sender, FormClosedEventArgs e)
        {
            AnaEkran anaekran = new AnaEkran();
            anaekran.Show();
        }
    }
}
