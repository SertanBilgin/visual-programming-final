﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;


namespace Görsel_Final
{
    public partial class Saha : Form
    {
        public MySqlConnection mysqlbaglan = new MySqlConnection("Server=127.0.0.1;Database=badminton;Uid=root;Pwd='147896325';");
        public Saha()
        {
            InitializeComponent();
        }

        private void Saha_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile("C:\\saha1.jpg");
            pictureBox2.Image = Image.FromFile("C:\\badd.jpg");

            VeriGetir();

        }
        private void VeriGetir()
        {
            string a = "Select özellik1 from saha WHERE Saha_id = 1";
            string b;
            MySqlCommand komut = new MySqlCommand(a, mysqlbaglan);
            mysqlbaglan.Open();
            b = (string)komut.ExecuteScalar();
            mysqlbaglan.Close();
            label1.Text = b;

            string a2 = "Select özellik2 from saha WHERE Saha_id = 1";
            string b2;
            MySqlCommand komut2 = new MySqlCommand(a2, mysqlbaglan);
            mysqlbaglan.Open();
            b2 = (string)komut2.ExecuteScalar();
            mysqlbaglan.Close();
            label2.Text = b2;

            string a3 = "Select renk from saha WHERE Saha_id = 1";
            string b3;
            MySqlCommand komut3 = new MySqlCommand(a3, mysqlbaglan);
            mysqlbaglan.Open();
            b3 = (string)komut3.ExecuteScalar();
            mysqlbaglan.Close();
            label3.Text = b3;

            string a4 = "Select özellik1 from saha WHERE Saha_id = 2";
            string b4;
            MySqlCommand komut4 = new MySqlCommand(a4, mysqlbaglan);
            mysqlbaglan.Open();
            b4 = (string)komut4.ExecuteScalar();
            mysqlbaglan.Close();
            label4.Text = b4;

            string a5 = "Select özellik2 from saha WHERE Saha_id = 2";
            string b5;
            MySqlCommand komut5 = new MySqlCommand(a5, mysqlbaglan);
            mysqlbaglan.Open();
            b5 = (string)komut5.ExecuteScalar();
            mysqlbaglan.Close();
            label5.Text = b5;

            string a6 = "Select renk from saha WHERE Saha_id = 2";
            string b6;
            MySqlCommand komut6 = new MySqlCommand(a6, mysqlbaglan);
            mysqlbaglan.Open();
            b6 = (string)komut6.ExecuteScalar();
            mysqlbaglan.Close();
            label6.Text = b6;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult uyar;

            uyar = MessageBox.Show(this, textBox1.Text + " Bu Sahanın Kaydını Silmek istiyor musunuz?", "SİLME UYARISI", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (uyar == DialogResult.Yes)

            {
                int n = Convert.ToInt16(textBox1.Text);
                if (n == 1)
                {
                    pictureBox1.Visible = false;
                    label1.Visible = false;
                    label2.Visible=false;
                    label3.Visible=false;
                }
                else if (n == 2)
                {
                    pictureBox2.Visible = false;
                    label4.Visible = false;
                    label5.Visible = false;
                    label6.Visible = false;
                }
                mysqlbaglan.Open();
                string sil = "DELETE FROM saha " + "Where id = '" + n + "'";
                MySqlCommand komut = new MySqlCommand(sil, mysqlbaglan);
                komut.ExecuteNonQuery();
                mysqlbaglan.Close();

            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Saha_FormClosed(object sender, FormClosedEventArgs e)
        {
            AnaEkran anaekran = new AnaEkran();
            anaekran.Show();
        }
    }
}
