using MySql.Data.MySqlClient;
using MySql.Data;
using System.Data;
using System.Xml.Linq;
using System.Windows.Forms;

namespace Görsel_Final
{
    public partial class AnaEkran : Form
    {

        public MySqlConnection mysqlbaglan = new MySqlConnection("Server=127.0.0.1;Database=badminton;Uid=root;Pwd='147896325';");

        public AnaEkran()
        {
            InitializeComponent();
        }


        private const string api = "b87d124450c2c1d68a146fceec3d1a63";
        // hava durumu bilgileri bir alt satırdaki web adresinden çekilecektir
        private const string baglanti = "http://api.openweathermap.org/data/2.5/weather?q=Turkey,Ankara&mode=xml&units=metric&APPID=" + api;

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void AnaEkran_Load(object sender, EventArgs e)
        {
            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            pictureBox3.Visible = false;

            XDocument Hava = XDocument.Load(baglanti);
            var Sicaklik = Hava.Descendants("temperature").ElementAt(0).Attribute("value").Value;
            label3.Text = Sicaklik.ToString() + "°";

            //aşağıda yazılan kod satırları için bu siteden faydalanıyoruz.
            var Durum = Hava.Descendants("clouds").ElementAt(0).Attribute("name").Value;
            label4.Text = Durum.ToString();
            pictureBox1.ImageLocation = "https://w7.pngwing.com/pngs/656/864/png-transparent-weather-forecasting-cloud-overcast-wind-cloud-heart-weather-forecasting.png";
                pictureBox2.ImageLocation = "https://w7.pngwing.com/pngs/533/833/png-transparent-weather-forecasting-computer-icons-android-cloudy-angle-cloud-weather-forecasting.png";
            pictureBox3.ImageLocation = "https://w7.pngwing.com/pngs/642/891/png-transparent-weather-forecasting-computer-icons-meteorology-sun-cloud-weather-forecasting-meteorology.png";
            if (Durum.Contains("clouds") == true)
            {
                pictureBox1.Visible = true;
            }
            if (Durum.Contains("clear sky") == true)
            {
                pictureBox1.Visible = false;
                pictureBox2.Visible = true;
            }
            if (Durum.Contains("sun") == true)
            {
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = true;
            }
            mysqlbaglan.Open();

        }

        private void oyuncularToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void raketlerToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void genelBilgilerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GenelBilgiler genelBilgiler = new GenelBilgiler();
            genelBilgiler.Show();
            this.Hide();
            

        }

        private void sahalarıGörüntüleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Saha saha = new Saha();
            saha.Show();
            this.Hide();

        }



        private void badmintonTopuMarkalarıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BadmintonTopu badmintontopu = new BadmintonTopu();
            badmintontopu.Show();
            this.Hide();

        }

        private void antrenörleriListeleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Antrenörler antrenörler = new Antrenörler();
            antrenörler.Show();
            this.Hide();

        }





        private void başkanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Başkan başkan = new Başkan();
            başkan.Show();
            this.Hide();

        }
        private void genelBilgilerVeTarihçeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GenelBilgilerVeTarihçe genelbilgilervetarihçe = new GenelBilgilerVeTarihçe();
            genelbilgilervetarihçe.Show();
            this.Hide();

        }



        
        private void raketMarkalarıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RaketMarkaları raket = new RaketMarkaları();
            raket.Show();
            this.Hide();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void raketToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BadmintonTopu badmintonTopu = new BadmintonTopu();
            badmintonTopu.Show();
            this.Hide();

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void AnaEkran_FormClosed(object sender, FormClosedEventArgs e)
        {

        }
    }
}