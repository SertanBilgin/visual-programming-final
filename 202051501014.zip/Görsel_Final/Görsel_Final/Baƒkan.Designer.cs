﻿namespace Görsel_Final
{
    partial class Başkan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(268, 224);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Items.AddRange(new object[] {
            "İŞ TECRÜBESİ :",
            "",
            "– 4 dönem 20004-2020 ( 16 Yıl ) Badminton Federasyonu Başkanlığı yapmaktadır.",
            "",
            "– Milli Eğitim Bakanlığında 18 Yıl Öğretmen (Uzman) olarak görev yapmıştır.",
            "",
            "– Avrupa Badminton Federasyonu As Başkanlığı yapmıştır. ( 2014 – 2018 )",
            "",
            "– Halen Akdeniz Badminton Federasyonu Başkanıdır. ( 2013 – … )",
            "",
            "– Halen Balkan Badminton Federasyonu As Başkanı’dır. ( 2008 – … )",
            "",
            "– Manisa Gençlik Hizmetleri ve Sp.İl Müdürlüğü yapmıştır. ( 2013-2014 )",
            "",
            "– Spor Genel Müdür Müşavirliği yapmıştır. ( 2014-2018 )",
            "",
            "– Gençlik ve Spor Bakanlığında Halen Genel Sekreter Kadrosunda görev yapmaktadır." +
                " ( 2019 – … )"});
            this.listBox1.Location = new System.Drawing.Point(351, 45);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(635, 384);
            this.listBox1.TabIndex = 1;
            // 
            // Başkan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGreen;
            this.ClientSize = new System.Drawing.Size(1053, 662);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Başkan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Başkan";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Başkan_FormClosed);
            this.Load += new System.EventHandler(this.Başkan_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private PictureBox pictureBox1;
        private ListBox listBox1;
    }
}