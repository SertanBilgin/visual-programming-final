﻿using MySql.Data.MySqlClient;
using MySql.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Görsel_Final
{
    public partial class KAYITOL : Form
    {
        public KAYITOL()
        {
            InitializeComponent();
        }
        public MySqlConnection mysqlbaglan = new MySqlConnection("Server=127.0.0.1;Database=badminton;Uid=root;Pwd='147896325';");

        private void button1_Click(object sender, EventArgs e)
        {
          
                try
                {

                if (textBox1.Text == ("") || textBox2.Text == ("") || textBox3.Text == ("") || textBox4.Text == ("") || textBox5.Text == (""))
                {
                    MessageBox.Show("lütfen boş yer bırakmayınız");

                }
                else
                {
                    mysqlbaglan.Open();
                    // ekleme komutunu tanımladım ve insert sorgusunu yazdım.
                    MySqlCommand ekle = new MySqlCommand("insert into giris (Adi,Soyadi,dogumTarihi,kullaniciAdi,sifre) values ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox5.Text + "','" + textBox3.Text + "','" + textBox4.Text + "')", mysqlbaglan);
                    // sorguyu çalıştırıyorum.
                    object sonuc = null;
                    sonuc = ekle.ExecuteNonQuery(); // sorgu çalıştı ve dönen değer objec türünden değişkene geçti eğer değişken boş değilse eklendi boşşsa eklenmedi.
                    if (sonuc != null)
                        MessageBox.Show("Kayıt Oldunuz.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show("Kaydınızda Bir Hata Var", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    mysqlbaglan.Close();
                }
                }
                catch (Exception HataYakala)
                {
                    MessageBox.Show("Hata: " + HataYakala.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
        }

        private void KAYITOL_Load(object sender, EventArgs e)
        {

        }
    }
}
