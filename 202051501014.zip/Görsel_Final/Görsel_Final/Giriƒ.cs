﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
namespace Görsel_Final
{
    public partial class Giriş : Form
    {
        public Giriş()
        {
            InitializeComponent();
        }
        public MySqlConnection mysqlbaglan = new MySqlConnection("Server=127.0.0.1;Database=badminton;Uid=root;Pwd='147896325';");


        private void button2_Click(object sender, EventArgs e)
        {
            KAYITOL kayıtol = new KAYITOL();
            kayıtol.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
               string ad = textBox1.Text;
               string sifre = textBox2.Text;
             MySqlCommand  cmd = new MySqlCommand();
               mysqlbaglan.Open();
               cmd.Connection = mysqlbaglan;
               cmd.CommandText = "SELECT * FROM giris where kullaniciAdi='" + textBox1.Text + "' AND sifre='" + textBox2.Text + "'";
              MySqlDataReader dr = cmd.ExecuteReader();
               if (dr.Read())
               {
                  AnaEkran anaEkran = new AnaEkran();
                   anaEkran.Show();
                   this.Hide();
               }
               else
               {
                   MessageBox.Show("Kullanıcı adı ya da şifre yanlış");
               }

               mysqlbaglan.Close();
            
            {
               /*try
                {
                    
                    MySqlCommand cmd = new MySqlCommand("select admin from giris where kullaniciAdi = @kullaniciAdi and sifre = @sifre", mysqlbaglan);
                    cmd.Parameters.AddWithValue("@kullaniciAdi", textBox1.Text);
                    cmd.Parameters.AddWithValue("@sifre", textBox2.Text);
                    cmd.Connection.Open();
                    MySqlDataReader rd = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                    if (rd.HasRows) // Girilen K.Adı ve K.Parola Dahilinde Gelen Data var ise 
                    {
                        while (rd.Read()) // reader Okuyabiliyorsa
                        {
                            if (rd["admin"].ToString() == "1") // 1 Rolü Admin'e ait olarak Ayarlanmışdır
                            {
                                AnaEkran ana = new AnaEkran();
                                ana.Show();
                                this.Hide();
                            }
                            else
                            {
                                
                            }   
                        }
                    }
                    else /// Reader SATIR döndüremiyorsa K.Adı Parola Yanlış Demekdir
                    {
                        rd.Close();
                        MessageBox.Show("Kullanıcı Adı veya Parola Geçersizdir", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch // Bağlantı açamayıp Sorgu Çalıştıramıyorsa Veritabanına Ulaşamıyor Demekdir
                {
                    MessageBox.Show("DB ye ulaşılamadı", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }*/
            }
        }
    }
}
