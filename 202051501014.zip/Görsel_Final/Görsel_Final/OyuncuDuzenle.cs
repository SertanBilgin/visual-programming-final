﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;


namespace Görsel_Final
{
    public partial class OyuncuDuzenle : Form
    {
        public OyuncuDuzenle()
        {
            InitializeComponent();
        }


        private void OyuncuDuzenle_Load(object sender, EventArgs e)
        {

        }
    }
}
