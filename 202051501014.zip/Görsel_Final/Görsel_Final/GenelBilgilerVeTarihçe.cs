﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Görsel_Final
{
    public partial class GenelBilgilerVeTarihçe : Form
    {
        public GenelBilgilerVeTarihçe()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Visible = true;
            listBox2.Visible = false;
            listBox3.Visible = false;
        }

        private void GenelBilgilerVeTarihçe_Load(object sender, EventArgs e)
        {
            listBox1.Visible = false;
            listBox2.Visible = false;
            listBox3.Visible =false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Visible = false;
            listBox2.Visible = true;
            listBox3.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Visible = false;
            listBox2.Visible = false;
            listBox3.Visible = true;
        }
    }
}
